#include "Canvas.h"

Canvas::Canvas(sf::RenderWindow &renderWindow) : m_renderWindow(renderWindow)
{
}

void Canvas::renderScene()
{
}

void Canvas::removeUIElement()
{
}

void Canvas::addElement(UIElement uiElement)
{
}
