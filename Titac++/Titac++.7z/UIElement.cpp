#include "UIElement.h"
#include <SFML/Graphics.hpp>

UIElement::UIElement(const Rect& rect, const UIElement* parent) : m_rect(rect), m_parent(parent)
{
}

void UIElement::loadImage(const std::string& name)
{
}

void UIElement::setSize(unsigned int width, unsigned int height)
{
	m_rect = Rect(width, height, m_rect.x, m_rect.y);
}

void UIElement::setPosition(unsigned int x, unsigned int y)
{
	m_rect = Rect(m_rect.width, m_rect.height, x, y);
}

const Rect & UIElement::getRect()
{
	return m_rect;
}

void UIElement::draw(sf::RenderWindow &window, int offsetX, int offsetY)
{
	onDraw(window, offsetX, offsetY);
	for(auto& child : m_children)
		child->onDraw(window, offsetX + m_rect.x, offsetY + m_rect.y);
}
