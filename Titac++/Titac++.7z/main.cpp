#include <SFML/Graphics.hpp>
#include <string>

#include "UIImage.h"

int main()
{
	std::string windowName = "TEST";
	sf::RenderWindow window(sf::VideoMode(500, 500), windowName);

	//auto res = ResourceManager<ResourceImage>::get().loadResource("test.jpg");
	//sf::Sprite sprite;
	//sprite.setTexture(res->getTexture());
	//sprite.setPosition(0, 0);
	UIImage test(Rect(0, 0, 256, 256), nullptr, "test.jpg");

	while (window.isOpen())
	{
		sf::Event event;
		while (window.pollEvent(event))
		{
			if (event.type == sf::Event::Closed)
				window.close();
		}

		window.clear();
		//window.draw(sprite);
		test.onDraw(window, 0, 0);
		window.display();
	}

	return 0;
}