#include "UIImage.h"
#include <SFML/Graphics.hpp>

class UIImage::SFGraphicsImpl
{
public:
	SFGraphicsImpl(const std::string& path) : m_sprite(std::make_unique<sf::Sprite>())
	{
		m_resource = ResourceManager<ResourceImage>::get().loadResource(path);
		m_sprite->setTexture(m_resource->getTexture());
	}
	void draw(sf::RenderWindow& window, int offsetX, int offsetY)
	{
		window.draw(*m_sprite);
	}
private:
	std::unique_ptr<sf::Sprite> m_sprite;
	std::shared_ptr<ResourceImage> m_resource;
};

UIImage::~UIImage()
{
}

UIImage::UIImage(Rect rect, const UIElement* parent, const std::string& path)
	: UIElement(rect, parent), pimpl(std::make_unique<SFGraphicsImpl>(path))
{
}

void UIImage::onDraw(sf::RenderWindow& window, int offsetX, int offsetY)
{
	pimpl->draw(window, offsetX, offsetY);
}
