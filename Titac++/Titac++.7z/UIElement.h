#pragma once
#include "Rect.h"
#include <string>
#include <memory>
#include <vector>

class Scene;
namespace sf { class RenderWindow; }

class UIElement {
private:
	const UIElement* m_parent = nullptr;
	std::vector<std::unique_ptr<UIElement>> m_children;
	Rect m_rect;

public:
	UIElement(const Rect& rect, const UIElement* parent);
	void loadImage(const std::string& name);
	void setSize(unsigned int width, unsigned int height);
	void setPosition(unsigned int x, unsigned int y);
	const Rect& getRect();

	virtual void onDraw(sf::RenderWindow &window, int offsetX, int offsetY) {};

private:
	void draw(sf::RenderWindow &window, int offsetX, int offsetY);
	friend class Scene;
};